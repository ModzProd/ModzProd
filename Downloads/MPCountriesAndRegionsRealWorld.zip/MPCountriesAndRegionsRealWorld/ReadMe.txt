MP Countries and Regions Real World

Database for Countries and Regions, with all countries of the continents.

Upcoming Updates: Addition of Subregions

Note: Some countries may be considered duplication errors, but they are transcontinental countries, any errors found or information that is missing, report it on the ModzProd discord server.


Discord Server ModzProd Feedback: https://discord.gg/sUqXGH38kP